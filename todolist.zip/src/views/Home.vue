<template>
  <div class="home">
    <h2>2020年惊天计划</h2>
    <input type="text" v-model="todo">
    <button @click='add()'>确定</button>
    <h3>未实现</h3>
    <ul>
      <li v-for='(item,index) in list' v-if='!item.checked'>
        <input type="checkbox" v-model="item.checked">
        {{item.title}}
        <button class="on" @click='onadd(index)'>删除</button>   
      </li>
    </ul>
    <h3>已实现</h3>
    <ul>
      <li v-for='(item,index) in list' v-if='item.checked'>
        <input type="checkbox" v-model="item.checked">
        {{item.title}} 
        <button class="on" @click='onadd(index)'>删除</button>   
      </li>
    </ul>
  </div>
</template>

<script>

export default {
  name: 'Home',
  data(){
    return{
      todo : '',
      list : []
    }
  },
  methods:{
    add(){
      //双向绑定
      this.list.push({
        title:this.todo,
        checked:false
      })
      //清楚输入框
      this.todo = ''
    },
    onadd(index){
      //删除方法 , 通过对数组进行切割
      this.list.splice(index,1)
    }
  }
}
</script>
<style>
  ul{
    list-style: none;
  } 
  li{
    width: 300px;
    padding-top:10px;
    padding-bottom:10px;
    margin:5px auto 0;
    background-color: red;
    color:#fff;
  }

</style>